package com.warrantyapp.warrantywiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarrantyWizApplicationTests {

	@Test
	void contextLoads() {
	}

}
