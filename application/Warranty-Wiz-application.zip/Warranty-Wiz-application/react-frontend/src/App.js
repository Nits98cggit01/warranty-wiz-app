import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from './Theme';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import WarrantyForm from './components/WarrantyForm';

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Switch>
          <Route exact path="/" component={Login} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/warranty-form" component={WarrantyForm} />
        </Switch>
      </Router>
    </ThemeProvider>
  );
}

export default App;
