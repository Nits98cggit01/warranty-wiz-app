import React from 'react';
import { Typography, Container, Paper, Button } from '@mui/material';
import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <Container maxWidth="lg">
      <Paper elevation={3} style={{ padding: 20, marginTop: 50 }}>
        <Typography variant="h4" gutterBottom>
          Welcome to Warranty-Wiz Dashboard
        </Typography>
        <Typography variant="body1" paragraph>
          Here you can manage your extended warranty products and policies.
        </Typography>
        <Button
          variant="contained"
          color="primary"
          component={Link}
          to="/warranty-form"
        >
          Create New Warranty
        </Button>
      </Paper>
    </Container>
  );
}

export default Dashboard;